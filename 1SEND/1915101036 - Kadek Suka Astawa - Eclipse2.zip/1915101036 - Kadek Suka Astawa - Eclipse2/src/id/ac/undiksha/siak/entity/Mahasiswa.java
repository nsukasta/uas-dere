package id.ac.undiksha.siak.entity;

import id.ac.undiksha.siak.organisasi.Prodi;

public class Mahasiswa extends Manusia {
	
	private String 	nim;
	private String 	angkatan;
	private String	kelas;
	
	public  Prodi  prodi = new Prodi();
	
	public void setNim(String nim) {
		this.nim = nim;
	}

	public String getNim() {
		return this.nim;
	}

	public String getAngkatan() {
		return angkatan;
	}

	public void setAngkatan(String angkatan) {
		this.angkatan = angkatan;
	}

	public String getKelas() {
		return kelas;
	}

	public void setKelas(String kelas) {
		this.kelas = kelas;
	}

	

}

