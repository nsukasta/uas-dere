package id.ac.undiksha.siak.main;

import id.ac.undiksha.siak.entity.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mahasiswa mhs1 = new Mahasiswa();
		
		mhs1.setNim("1915101061");
		mhs1.setNamaDepan("Made");
		mhs1.setNamaBelakang("Ariawan");
		mhs1.setJenisKelamin(true);
		mhs1.setAlamat("Singaraja");
		mhs1.setTglLahir("10 Agustus 2000");
		mhs1.setNoKTP("1322143225656");
		
		
		System.out.println(mhs1.getNim());
		System.out.println(mhs1.getNamaLengkap());
		System.out.println(mhs1.getJenisKelamin());
		System.out.println(mhs1.getAlamat());
		System.out.println(mhs1.getTglLahir());
		System.out.println(mhs1.getNoKTP());
		
		Pegawai pgw1 = new Pegawai();
		
		pgw1.setNamaDepan("Nama");
		pgw1.setNip("32143265475");
		
		Dosen ds1  = new Dosen();
		
		ds1.setNidn("1214");
		ds1.setNip("132214325646");
		ds1.setNamaDepan("namaDepan");
		
		ds1.prodi.setNamaProdi("Ilmu Komputer");
		
		System.out.println(ds1.prodi.getNamaProdi());
		
		
	}

}
