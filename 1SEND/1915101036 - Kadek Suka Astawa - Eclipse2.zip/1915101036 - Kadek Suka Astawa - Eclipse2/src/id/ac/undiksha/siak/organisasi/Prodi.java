package id.ac.undiksha.siak.organisasi;

public class Prodi {

	private String kodeProdi;
	private String namaProdi;
	private String url;
	private String jurusan;
	private String fakultas;
	
	
	public String getKodeProdi() {
		return kodeProdi;
	}
	public void setKodeProdi(String kodeProdi) {
		this.kodeProdi = kodeProdi;
	}
	public String getNamaProdi() {
		return namaProdi;
	}
	public void setNamaProdi(String namaProdi) {
		this.namaProdi = namaProdi;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getJurusan() {
		return jurusan;
	}
	public void setJurusan(String jurusan) {
		this.jurusan = jurusan;
	}
	public String getFakultas() {
		return fakultas;
	}
	public void setFakultas(String fakultas) {
		this.fakultas = fakultas;
	}
	
	
	
	
}
