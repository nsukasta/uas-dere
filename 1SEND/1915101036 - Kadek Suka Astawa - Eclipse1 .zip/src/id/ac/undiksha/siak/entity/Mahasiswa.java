package id.ac.undiksha.siak.entity;

public class Mahasiswa {
	
	private String 	nim;
	private String 	namaDepan, namaBelakang;
	private boolean jenisKelamin; // 0 = Perempuan - 1 = Laki-Laki
	private String 	tglLahir;
	private String 	alamat;
	
	
	public void setNim(String nim) {
		this.nim = nim;
	}

	public String getNim() {
		return this.nim;
	}

	public String getNamaDepan() {
		return namaDepan;
	}

	public void setNamaDepan(String namaDepan) {
		this.namaDepan = namaDepan;
	}

	public String getNamaBelakang() {
		return namaBelakang;
	}
	
	public String getNamaLengkap() {
		return this.getNamaDepan() + " " + this.getNamaBelakang();
	}

	public void setNamaBelakang(String namaBelakang) {
		this.namaBelakang = namaBelakang;
	}

	public boolean isJenisKelamin() {
		return jenisKelamin;
	}

	public String getJenisKelamin() {
		
		if (this.isJenisKelamin()) {
			return "Laki-Laki";
		} 
		
		else {
			return "Perempuan";
		}
	}
	
	public void setJenisKelamin(boolean jenisKelamin) {
		this.jenisKelamin = jenisKelamin;
	}
	
		public String getTglLahir() {
		return tglLahir;
	}

	public void setTglLahir(String tglLahir) {
		this.tglLahir = tglLahir;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	
	

}

