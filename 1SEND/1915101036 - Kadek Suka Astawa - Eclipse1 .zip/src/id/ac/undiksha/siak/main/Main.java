package id.ac.undiksha.siak.main;

import id.ac.undiksha.siak.entity.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mahasiswa mhs1 = new Mahasiswa();
		
		mhs1.setNim("1915101061");
		mhs1.setNamaDepan("Made");
		mhs1.setNamaBelakang("Ariawan");
		mhs1.setJenisKelamin(true);
		mhs1.setAlamat("Singaraja");
		mhs1.setTglLahir("10 Agustus 2000");
		
		System.out.println(mhs1.getNim());
		System.out.println(mhs1.getNamaLengkap());
		System.out.println(mhs1.getJenisKelamin());
		System.out.println(mhs1.getAlamat());
		System.out.println(mhs1.getTglLahir());
		
		
		
		
	/*	mhs1.namaDepan		= "Made";
		mhs1.namaBelakang	= "Ariawan";
		mhs1.jenisKelamin 	= true;
		mhs1.tglLahir 		= "10 Agustus 2000";
		
		System.out.println(mhs1.nim);
		System.out.println(mhs1.namaDepan + " " + mhs1.namaBelakang);
		
		Mahasiswa mhs2 = new Mahasiswa();
		
		mhs2.nim			= "1915101062";
		mhs2.namaDepan		= "Putu";
		mhs2.namaBelakang	= "Bunga";
		mhs2.jenisKelamin 	= false;
		mhs2.tglLahir 		= "11 Juni 2001";
		
		System.out.println(mhs2.nim);
		System.out.println(mhs2.namaDepan + " " + mhs2.namaBelakang); */
		
		
		
	}

}
